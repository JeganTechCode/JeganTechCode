module.exports = {
    dbName: "Book",
    mongodburi: "mongodb://localhost:27017/<database>",
}
